#!/bin/sh

PFRING_HOME=$1

PFRING_BIN=$PFRING_HOME/bin
PFRING_LIB=$PFRING_HOME/lib
PFRING_DRIVERS=$PFRING_HOME/drivers
PFRING_INCDIR=$PFRING_HOME/include

RET_OK="0"
RET_ERROR="1"

if [ "$UID" -ne 0 ]; then
    echo "You must be supervisor to run it."
    exit 1
fi

#CREATE PF_RING HOME DIRECOTRY.
if [ ! -d "$PFRING_HOME" ]; then
    mkdir $PFRING_HOME
fi

if [ ! -d "$PFRING_INCDIR" ]; then
    mkdir $PFRING_INCDIR
fi

#INSTALL PFRING KERNEL MODULE.
install_kernel () {
    if [ ! -d "$PFRING_DRIVERS" ]; then
        mkdir $PFRING_DRIVERS
    fi
 
    if ! ( cd kernel && \
           make && \
           install -m 0644 pf_ring.ko $PFRING_DRIVERS)>/dev/null 2>&1; then
        return $RET_ERROR
    fi

    if [ -d "kernel/plugins" ]; then
        ( cd kernel/plugins && make )>/dev/null 2>&1
        if [ ! -d "$PFRING_DRIVERS/plugins" ]; then
            mkdir $PFRING_DRIVERS/plugins
        fi
        install -m 0644 kernel/plugins/*.ko $PFRING_DRIVERS/plugins
    fi

    cp -r kernel/linux $PFRING_INCDIR/
    return $RET_OK
}

install_driver() {
    files=`ls $1`
    for f in `ls $1`
    do
        if [ -d "$1/$f" ]; then
            install_driver $1/$f $2
        else
            suffix=`echo $f | awk -F"." '{print $NF;}'`
            if [ "$suffix" == "ko" ]; then
                install -m 0644 $1/$f $2/
            fi
        fi
    done
}

#INSTALL DNA DRIVERS FOR VARIOUS NICs.
install_drivers() {
    dna_path=$PFRING_DRIVERS/DNA
    aware_path=$PFRING_DRIVERS/aware

    if [ ! -d "$dna_path" ]; then
        mkdir $dna_path
    fi

    if [ ! -d "$aware_path" ]; then
        mkdir $aware_path
    fi

    if ! ( cd drivers && \
           cd DNA && make && \
           cd ../PF_RING_aware && make )>/dev/null 2>&1; then
        echo "Can not instal DNA drivers."
        return $RET_ERROR
    else
        install_driver drivers/DNA $dna_path
        install_driver drivers/PF_RING_aware $aware_path
    fi

    return $RET_OK
}


#INSTALL LIBRARIES.
install_pfring() {
    if [ ! -d "$PFRING_BIN" ]; then
        mkdir $PFRING_BIN
    fi

    if ! ( cd userland/lib && \
           ./configure --prefix=$PFRING_HOME && \
           make && \
           make install )>/dev/null 2>&1; then
        echo "Can not install pfring library."
        return $RET_ERROR
    fi

    if ! ( cd userland/libpcap && \
           ./configure --prefix=$PFRING_HOME && \
           make && \
           make install )>/dev/null 2>&1; then
        echo "Can't install libpcap for pfring."
        return $RET_ERROR
    fi

    if ! ( cd userland/c++ && make )>/dev/null 2>&1; then
        echo "Can not compile C++ library for pfring."
        return $RET_ERROR
    else
        cp -rf userland/c++/PFring.h $PFRING_INCDIR/
        cp -rf userland/c++/libpfring_cpp.a $PFRING_LIB/
    fi

    if ! ( cd userland/examples && \
           make )>/dev/null 2>&1; then
        echo "Can not compile pfring tools."
        return $RET_ERROR
    else
        tools=`ls userland/examples`
        for t in $tools
        do
            t=userland/examples/$t
            if [ -x "$t" ]; then
                install -m 0755 $t $PFRING_BIN
            fi
        done
    fi

    return $RET_OK
}

if ! ( install_kernel && \
       install_drivers && \
       install_pfring ); then
    exit 1
fi

exit 0
